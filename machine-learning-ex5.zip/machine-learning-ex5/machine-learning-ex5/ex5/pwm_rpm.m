clear ; close all; clc

data = load ('pwm_rpm.txt');
X = data(:, 2)
y = data(:, 1)
z=zeros(26,1);
for i=1:24,
    z(i+1) = (y(i+1) - y(i)) / (X(i+1) - X(i));
    d(i+1) = (y(i+2) - 2*y(i+1) + y(i)) / (X(i+2) - 2*X(i+1) +X(i));
end;
    

m = length(y); % number of training examples

p = 4; 

% Map X onto Polynomial Features and Normalize
X_poly = polyFeatures(X, p);
[X_poly, mu, sigma] = featureNormalize(X_poly)  % Normalize
X_poly = [ones(m, 1) X_poly]
 %y = log(y);


lambda = 0;
[theta] = trainLinearReg(X_poly, y, lambda)

figure(1);
plot(X, z, 'rx', 'MarkerSize', 10, 'LineWidth', 1.5);
hold on;
plot(X(1:25,:), d, 'kx', 'MarkerSize', 10, 'LineWidth', 1.5);
plot(X, y, 'bx', 'MarkerSize', 10, 'LineWidth', 1.5);

% plotFit(min(X), max(X), mu, sigma, theta, p);
xlabel('RPM');
ylabel('PWM');
title (sprintf('Polynomial Regression Fit (lambda = %f)', lambda));

a = polyFeatures(X, p);
a1 = bsxfun(@minus, a, mu);

a1 = bsxfun(@rdivide, a1, sigma);
a1 = [ones(size(X,1),1) a1]
pwm = a1*theta
[J, grad] = linearRegCostFunction([ones(m,1) a], pwm, theta, lambda)